public class Main {
    public static void printStudentInfo(Student student){
        System.out.println("Name: " + student.getName());
        student.getAddress().ifPresent(address -> {
            System.out.println("Address: " + address.getCity() + ", " + address.getRegion());
        });
    }

    public static void main(String[] args) {
        Student student1 = new Student("John", new Address("New York", "NY"));
        Student student2 = new Student("Emily",  new Address("Toronto", "Toronto"));
        Student student3 = new Student("Mary");

        printStudentInfo(student1);
        printStudentInfo(student2);
        printStudentInfo(student3);
    }
}
