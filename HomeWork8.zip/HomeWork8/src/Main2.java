import java.util.Arrays;
import java.util.List;
public class Main2 {
    public static void main(String[] args) {
        List<String> words = Arrays.asList("Hello", "everyone", "How", "is", "going", "I", "am", "Andrew.");
        String sentence = words.stream().reduce((s1, s2) -> s1 + " " + s2).orElse("");
        System.out.println("Words: " + words);
        System.out.println("Sentence: " + sentence);
    }
}